package model;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class MyConnection {
	public static Session getConnection()
	{
		//using configuration file, i need to connect to the oracle db
		//so first represent the configuration file as an object
		Configuration config=new Configuration();
		config.configure("hibernate.cfg.xml");
		//using this file, i need to login to oracle db. using username and password in fact using url
		//login and establish a session
		SessionFactory sf = config.buildSessionFactory();
		//this sf obj encapsulates the information you provided in cfg file
		//using this we can login or logout
		Session session = sf.openSession();		//here we login
		return session;
	}
	public static Session getConn2()
	{
		return new Configuration().configure("hibernate.cfg.xml").buildSessionFactory().openSession();
	}
}
