package model;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class VehicleDAO {
	
	public void create(Vehicle vehicle)	//detached entity only but without exising ID
	{
		Session session = MyConnection.getConnection();
		//if you do DML operation, then do it in a transaction
		Transaction tran = session.beginTransaction();
		session.persist(vehicle);		//for add/update
		//this vehicle is a detached entity
		tran.commit();
		session.close();
	}
	public List<Vehicle> read()
	{
		
//		Session session = getConn();
//		Criteria criteria = session.createCriteria(Patient.class);
//		List<Patient> result = criteria.list();
//		return result;
		
		Session session = MyConnection.getConnection();
		Criteria criteria = session.createCriteria(Vehicle.class);
		//without adding any criteria, i am going to list the result
		List<Vehicle> vehicleList=criteria.list();
		session.close();
		return vehicleList;
	}
	public Vehicle read(int id)
	{
		Session session = MyConnection.getConnection();
		Vehicle vehicle=(Vehicle) session.get(Vehicle.class, id);
		//this vehicle is not created by me. it is managed entity 
		//obtained from session. means, a row in table is sync with an object in java
		session.close();
		return vehicle;
	}
	public void update(Vehicle vehicle)	//vehicle is not in sync with db row so it is detached entity
	{
		Session session = MyConnection.getConnection();
		//do not begin transaction here itself. keep the tran time minimal
		Vehicle v=(Vehicle) session.get(Vehicle.class, vehicle.getId());
		//v is a managed entity
		v.setName(vehicle.getName());
		v.setType(vehicle.getType());
		v.setCompany(vehicle.getCompany());
		Transaction tran = session.beginTransaction();
		session.persist(v);
		tran.commit();
		session.close();
	}
	public void delete(int id)
	{
		Session session = MyConnection.getConnection();
		//find the object using id
		Vehicle vehicle=(Vehicle) session.get(Vehicle.class, id);
		Transaction tran = session.beginTransaction();
		session.delete(vehicle); 	//managed entity only 
		tran.commit();
		session.close();
	}
	public static void main(String[] args) {
//		Vehicle vehicle = new Vehicle(121, "Ciaz", "Sedan", "Suzuki"); //detached entity beos we created an object 
			//which is not sync with a row in the db
		VehicleDAO vdao=new VehicleDAO();
//		vdao.update(vehicle);
//		Vehicle vehicle = vdao.read(121);
//		System.out.println(vehicle);
		List<Vehicle> vehicles = vdao.read();
		System.out.println(vehicles);
		System.out.println("Done");
	}
}
