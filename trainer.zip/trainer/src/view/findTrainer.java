package view;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Trainer;
import model.TrainerDAO;

/**
 * Servlet implementation class findTrainer
 */
@WebServlet({ "/findTrainer", "/find" })
public class findTrainer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public findTrainer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id=Integer.parseInt(request.getParameter("id"));
		TrainerDAO tdao=new TrainerDAO();
		Trainer trainer=null;
		try {
			trainer=tdao.read(id);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(trainer!=null)
			response.sendRedirect("index.jsp?id="+trainer.getId()+"&firstName="+trainer.getFirstName()+"&lastName="+trainer.getLastName()+"&phone="+trainer.getPhone()+"&email="+trainer.getEmail()+"&skillSet="+trainer.getSkillSet()+"&experience="+trainer.getExperience());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
