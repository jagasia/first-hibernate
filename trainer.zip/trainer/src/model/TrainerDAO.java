package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TrainerDAO {
	public int create(Trainer trainer) throws ClassNotFoundException, SQLException
	{
		Connection con = MyConnection.getConnection();
		PreparedStatement st = con.prepareStatement("INSERT INTO TRAINER VALUES(default, ?,?,?,?,?,?)");
		st.setString(1, trainer.getFirstName());
		st.setString(2, trainer.getLastName());
		st.setString(3, trainer.getPhone());
		st.setString(4, trainer.getEmail());
		st.setString(5, trainer.getSkillSet());
		st.setInt(6, trainer.getExperience());
		int no=st.executeUpdate();
		con.close();
		return no;
	}
	public List<Trainer> read() throws ClassNotFoundException, SQLException
	{
		Connection con = MyConnection.getConnection();
		ResultSet rs = con.createStatement().executeQuery("SELECT * FROM TRAINER");
		List<Trainer> trainers=new ArrayList<>();
		while(rs.next())
		{
			Trainer trainer=new Trainer(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getInt(7));
			trainers.add(trainer);
		}
		con.close();
		return trainers;
	}
	public Trainer read(int id) throws ClassNotFoundException, SQLException
	{
		Connection con = MyConnection.getConnection();
		PreparedStatement st = con.prepareStatement("SELECT * FROM TRAINER WHERE id=?");
		st.setInt(1, id);
		ResultSet rs = st.executeQuery();
		Trainer trainer=null;
		if(rs.next())
		{
			trainer=new Trainer(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getInt(7));
		}
		con.close();
		return trainer;
	}
	public int update(Trainer trainer) throws ClassNotFoundException, SQLException
	{
		Connection con = MyConnection.getConnection();
		PreparedStatement st = con.prepareStatement("UPDATE TRAINER SET firstName=?, lastName=?, phone=?, email=?, skillSet=?, experience=? WHERE id=?");
		st.setString(1, trainer.getFirstName());
		st.setString(2, trainer.getLastName());
		st.setString(3, trainer.getPhone());
		st.setString(4, trainer.getEmail());
		st.setString(5, trainer.getSkillSet());
		st.setInt(6, trainer.getExperience());
		st.setInt(7, trainer.getId());
		int no=st.executeUpdate();
		con.close();
		return no;
	}
	public int delete(int id) throws ClassNotFoundException, SQLException
	{
		Connection con = MyConnection.getConnection();
		PreparedStatement st = con.prepareStatement("DELETE FROM TRAINER WHERE id=?");
		st.setInt(1, id);
		int no=st.executeUpdate();
		con.close();
		return no;
	}
//	public static void main(String[] args) throws ClassNotFoundException, SQLException {
//		TrainerDAO tdao=new TrainerDAO();
//		
////		tdao.create(new Trainer("Rajesh", "Nallusamy", "9797979797", "rajesh.n@gmail.com", "Java", 15));
//		Trainer trainer = tdao.read(5);
////		trainer.setSkillSet("java full stack");
////		tdao.update(trainer);
//		tdao.delete(5);
//		List<Trainer> trainers = tdao.read();
//		System.out.println(trainers);
//	}
}
