package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class MyConnection {
	public static Connection getConnection() throws ClassNotFoundException, SQLException
	{
		ResourceBundle rb = ResourceBundle.getBundle("dblocal");
		Class.forName(rb.getString("driver"));
		return DriverManager.getConnection(rb.getString("url"),rb.getString("username"),rb.getString("password"));
	}
}
