package controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Trainer;
import model.TrainerDAO;

/**
 * Servlet implementation class TrainerServlet
 */
@WebServlet({ "/TrainerServlet", "/trainer" })
public class TrainerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TrainerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String btn=request.getParameter("btn");
		String firstName="", lastName="", phone="", email="", skillSet="";
		int id=0, experience=0;
		
		if(btn.equals("Add") || btn.equals("Edit"))
		{
			firstName=request.getParameter("firstName");
			lastName=request.getParameter("lastName");
			phone=request.getParameter("phone");
			email=request.getParameter("email");
			skillSet=request.getParameter("skillSet");
			experience=Integer.parseInt(request.getParameter("experience"));
		}
		if(btn.equals("Delete") || btn.equals("Edit"))
		{
			id=Integer.parseInt(request.getParameter("id"));
		}
			TrainerDAO tdao=new TrainerDAO();
			Trainer trainer=null;
		switch(btn)
		{
		case "Add":
				trainer=new Trainer(firstName, lastName, phone, email, skillSet, experience);
			try {
				tdao.create(trainer);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case "Edit":
				trainer=new Trainer(id, firstName, lastName, phone, email, skillSet, experience);
			try {
				System.out.println("Going to edit : "+trainer);
				tdao.update(trainer);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case "Delete":
			try {
				tdao.delete(id);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		}
		response.sendRedirect("index.jsp");
	}

}
